<?php if (!defined('FW')) {
    die('Forbidden');
}

$options = array(


    'custom_class' => array(

        'label' => __('custom_class'),
        'desc'  => __('Insert custom class'),
        'type'  => 'text',
    )
);
