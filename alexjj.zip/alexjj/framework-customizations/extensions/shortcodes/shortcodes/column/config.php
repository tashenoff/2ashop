<?php if (!defined('FW')) die('Forbidden');
$cfg['page_builder'] = array(
    'title'       => __( 'custom column', 'fw' ),
    'description' => __( 'Это сделал алекс', 'fw' ),
    'tab'         => __( 'Кастомная колонка', 'fw' ),
    'disable_correction' => true,
);
